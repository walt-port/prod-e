exports.handler = async () => { return { statusCode: 200, body: "Notification sent" }; };
